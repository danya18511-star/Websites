(async () => {
  await window.DB.openDatabase();

  /************************************************************
   *  Encryption, Signup, and Password Generator
   ************************************************************/
  const cryptoHelpers = (() => {
    let sessionKey = null;

    function bufToHex(b) {
      return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
    }
    function hexToBuf(h) {
      const b = new Uint8Array(h.length / 2);
      for (let i = 0; i < b.length; i++) b[i] = parseInt(h.substr(i * 2, 2), 16);
      return b;
    }

    async function ensureSessionKey() {
      if (sessionKey) return;
      const pass = sessionStorage.getItem("app_passphrase") || prompt("Enter encryption passphrase:");
      if (!pass) throw new Error("No passphrase entered.");
      sessionStorage.setItem("app_passphrase", pass);
      const enc = new TextEncoder();
      const salt = new Uint8Array([0x42, 0x55, 0x99, 0x12, 0x22, 0x77, 0xA1, 0xFF, 0x10, 0x03, 0xA3, 0xB1, 0x19, 0x90, 0xD2, 0x55]);
      const baseKey = await crypto.subtle.importKey("raw", enc.encode(pass), { name: "PBKDF2" }, false, ["deriveBits", "deriveKey"]);
      sessionKey = await crypto.subtle.deriveKey(
        { name: "PBKDF2", salt, iterations: 200000, hash: "SHA-256" },
        baseKey,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
      );
    }

    async function encryptData(text) {
      await ensureSessionKey();
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const encoded = new TextEncoder().encode(String(text || ""));
      const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, sessionKey, encoded);
      return { ivHex: bufToHex(iv), cipherHex: bufToHex(cipher) };
    }

    async function decryptData(obj) {
      await ensureSessionKey();
      const iv = hexToBuf(obj.ivHex);
      const cipherBuf = hexToBuf(obj.cipherHex).buffer;
      const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, sessionKey, cipherBuf);
      return new TextDecoder().decode(plainBuf);
    }

    function generatePassword(length = 14) {
      const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+=";
      const random = crypto.getRandomValues(new Uint8Array(length));
      return Array.from(random, n => charset[n % charset.length]).join("");
    }

    return { encryptData, decryptData, generatePassword };
  })();

  /************************************************************
   *  Patient Login & Signup
   ************************************************************/
  const patientAccounts = JSON.parse(localStorage.getItem("patientAccounts") || "[]");

  function saveAccounts() {
    localStorage.setItem("patientAccounts", JSON.stringify(patientAccounts));
  }

  async function patientSignup() {
    const name = prompt("Enter your name:");
    const email = prompt("Enter your email:");
    if (!name || !email) return alert("Signup cancelled.");

    const generatedPassword = cryptoHelpers.generatePassword();
    alert(`Signup successful!\n\nYour generated password is:\n${generatedPassword}\n\nPlease remember this password.`);

    patientAccounts.push({ name, email, password: generatedPassword });
    saveAccounts();
  }

  async function patientLogin() {
    const logged = sessionStorage.getItem("patientLoggedIn");
    if (logged === "true") return true;

    const choice = confirm("Do you already have an account?");
    if (!choice) {
      await patientSignup();
    }

    const email = prompt("Enter your email:");
    const password = prompt("Enter your password:");
    const match = patientAccounts.find(acc => acc.email === email && acc.password === password);

    if (match) {
      alert(`Welcome, ${match.name}!`);
      sessionStorage.setItem("patientLoggedIn", "true");
      return true;
    } else {
      alert("Invalid credentials. Please try again.");
      return false;
    }
  }

  const loggedIn = await patientLogin();
  if (!loggedIn) return;

  /************************************************************
   *  Load patient.json and doctor.json + main functionality
   ************************************************************/
  async function loadJSON(fileName) {
    try {
      const res = await fetch(`./${fileName}`);
      if (!res.ok) throw new Error(`Failed to load ${fileName}`);
      return await res.json();
    } catch (err) {
      console.warn(`Failed to load ${fileName}:`, err);
      return [];
    }
  }

  const patients = await loadJSON('patient.json');
  const doctors = await loadJSON('doctor.json');
  const medicines = await window.DB.getAll('medicines');
  const appointments = await window.DB.getAll('appointments');

  // --- DOM Elements ---
  const patientIdInput = document.getElementById('patientId');
  const loadBtn = document.getElementById('loadPatient');
  const view = document.getElementById('patientView');
  const bookForm = document.getElementById('bookForm');

  // --- Load Patient Info by ID ---
  loadBtn.addEventListener('click', async () => {
    const id = patientIdInput.value.trim();
    if (!id) return alert('Please enter a Patient ID.');

    // Try IndexedDB first, then fallback to JSON
    let p = await window.DB.getByKey('patients', id);
    if (!p) p = patients.find(pt => String(pt.id) === id);

    if (!p) return alert('Patient not found.');
    renderPatient(p);
  });

  // --- Display Patient Info ---
  function renderPatient(p) {
    view.innerHTML = `
      <div class="patient-card">
        <h3>${p.Title ? p.Title + ' ' : ''}${p.First || ''} ${p.Last || ''}</h3>
        <p><strong>ID:</strong> ${p.id}</p>
        <p><strong>NHS Number:</strong> ${p.NHS || '—'}</p>
        <p><strong>Date of Birth:</strong> ${p.DOB || '—'}</p>
        <p><strong>Gender:</strong> ${p.Gender || '—'}</p>
        <p><strong>Address:</strong> ${p.Address || '—'}</p>
        <p><strong>Email:</strong> ${p.Email || '—'}</p>
        <p><strong>Telephone:</strong> ${p.Telephone || '—'}</p>
      </div>
    `;
    loadAppointments(p.id);
  }

  // --- Load Appointments ---
  async function loadAppointments(patientId) {
    const appts = await window.DB.getAll('appointments');
    const doctors = await loadJSON('doctor.json');

    const patientAppointments = appts.filter(a => String(a.patient_id) === String(patientId));
    if (patientAppointments.length > 0) {
      const apptList = patientAppointments.map(a => {
        const doc = doctors.find(d => String(d.id) === String(a.doctor_id));
        return `
          <li>
            <strong>Doctor:</strong> ${doc ? `Dr. ${doc.first_name} ${doc.last_name}` : a.doctor_id} <br>
            <strong>Date:</strong> ${a.date} <br>
            <strong>Notes:</strong> ${a.notes || '—'}
          </li>
        `;
      }).join('');
      view.innerHTML += `
        <h4>🗓 Your Appointments</h4>
        <ul>${apptList}</ul>
      `;
    } else {
      view.innerHTML += `<p>No appointments found.</p>`;
    }
  }

  // --- Book Appointment ---
  bookForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(bookForm).entries());
    const appointment = {
      id: Date.now(),
      patient_id: data.patient_id,
      doctor_id: data.doctor_id,
      date: data.date,
      notes: data.notes || '',
    };

    // Encrypt notes before saving (optional)
    if (appointment.notes) {
      appointment.notes_encrypted = await cryptoHelpers.encryptData(appointment.notes);
      appointment.notes = "(Encrypted)";
    }

    await window.DB.addRecord('appointments', appointment);
    alert('Appointment booked securely!');
    bookForm.reset();
  });
})();
