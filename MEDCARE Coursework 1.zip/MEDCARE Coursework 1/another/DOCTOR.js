// doctor.js — Unified & fixed
(async () => {

  /************************************************************
   * 1. Encryption + Password Generator
   ************************************************************/
  const cryptoHelpers = (() => {
    let sessionKey = null;

    function bufToHex(b) {
      return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
    }
    function hexToBuf(h) {
      const b = new Uint8Array(h.length / 2);
      for (let i = 0; i < b.length; i++) b[i] = parseInt(h.substr(i * 2, 2), 16);
      return b;
    }

    async function ensureSessionKey() {
      if (sessionKey) return;
      const pass = sessionStorage.getItem("app_passphrase") || prompt("Enter encryption passphrase:");
      if (!pass) throw new Error("No passphrase entered.");
      sessionStorage.setItem("app_passphrase", pass);
      const enc = new TextEncoder();
      const salt = new Uint8Array([0x42, 0x55, 0x99, 0x12, 0x22, 0x77, 0xA1, 0xFF, 0x10, 0x03, 0xA3, 0xB1, 0x19, 0x90, 0xD2, 0x55]);
      const baseKey = await crypto.subtle.importKey("raw", enc.encode(pass), { name: "PBKDF2" }, false, ["deriveBits", "deriveKey"]);
      sessionKey = await crypto.subtle.deriveKey(
        { name: "PBKDF2", salt, iterations: 200000, hash: "SHA-256" },
        baseKey,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
      );
    }

    async function encryptData(text) {
      await ensureSessionKey();
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const encoded = new TextEncoder().encode(String(text || ""));
      const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, sessionKey, encoded);
      return { ivHex: bufToHex(iv), cipherHex: bufToHex(cipher) };
    }

    async function decryptData(obj) {
      await ensureSessionKey();
      const iv = hexToBuf(obj.ivHex);
      const cipherBuf = hexToBuf(obj.cipherHex).buffer;
      const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, sessionKey, cipherBuf);
      return new TextDecoder().decode(plainBuf);
    }

    function generatePassword(length = 14) {
      const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+=";
      const random = crypto.getRandomValues(new Uint8Array(length));
      return Array.from(random, n => charset[n % charset.length]).join("");
    }

    return { encryptData, decryptData, generatePassword };
  })();

  /************************************************************
   * 2. Doctor Login
   ************************************************************/
  const doctorAccounts = [
    { username: "doctor1", password: "secure123" },
    { username: "doctor2", password: "password456" }
  ];

  async function doctorLogin() {
    if (sessionStorage.getItem("doctorLoggedIn") === "true") return true;
    const username = prompt("Enter Doctor Username:");
    const password = prompt("Enter Doctor Password:");
    const found = doctorAccounts.find(d => d.username === username && d.password === password);
    if (found) {
      alert("Login successful! Welcome, " + username);
      sessionStorage.setItem("doctorLoggedIn", "true");
      return true;
    } else {
      alert("Invalid credentials.");
      return false;
    }
  }

  if (!await doctorLogin()) return;

  /************************************************************
   * 3. Load JSON + DB Data
   ************************************************************/
  async function loadJSON(fileName) {
    try {
      const res = await fetch(`./${fileName}`);
      if (!res.ok) throw new Error(`Failed to load ${fileName}`);
      return await res.json();
    } catch (err) {
      console.warn(`Error loading ${fileName}:`, err);
      return [];
    }
  }

  const jsonPatients = await loadJSON("patient.json");
  const jsonMedicines = await loadJSON("Medicine.json");

  await window.DB.openDatabase();

  // Merge DB + JSON data
  const dbPatients = await window.DB.getAll("patients");
  const dbMeds = await window.DB.getAll("medicines");
  const patients = [...jsonPatients, ...dbPatients];
  const medicines = [...jsonMedicines, ...dbMeds];
  let appointments = [...(await window.DB.getAll("appointments")), ...JSON.parse(localStorage.getItem("appointments") || "[]")];

  /************************************************************
   * 4. DOM elements
   ************************************************************/
  const view = document.getElementById("docPatientView") || document.getElementById("view");
  const searchForm = document.getElementById("searchForm");
  const queryInput = document.getElementById("query");
  const lookupBtn = document.getElementById("docLookupBtn");
  const searchBox = document.getElementById("docSearch");

  /************************************************************
   * 5. Search (works with either form or button)
   ************************************************************/
  async function findPatient(query) {
    const q = query.trim().toLowerCase();
    return patients.find(
      p =>
        String(p.id).toLowerCase() === q ||
        ((p.name || `${p.First || ""} ${p.Last || ""}`).trim().toLowerCase() === q)
    );
  }

  async function handleSearch(query) {
    const patient = await findPatient(query);
    if (!patient) {
      view.innerHTML = "<p>Patient not found.</p>";
      return;
    }
    await renderPatient(patient);
  }

  if (lookupBtn && searchBox) {
    lookupBtn.addEventListener("click", () => handleSearch(searchBox.value));
  }
  if (searchForm && queryInput) {
    searchForm.addEventListener("submit", e => {
      e.preventDefault();
      handleSearch(queryInput.value);
    });
  }

  /************************************************************
   * 6. Render patient
   ************************************************************/
  async function renderPatient(p) {
    appointments = [...(await window.DB.getAll("appointments")), ...JSON.parse(localStorage.getItem("appointments") || "[]")];
    const patientAppts = appointments.filter(a => a.patient_id == p.id);

    view.innerHTML = `
      <div class="panel">
        <h3>${p.name || `${p.First || ""} ${p.Last || ""}`}</h3>
        <p>
          <strong>ID:</strong> ${p.id}<br>
          <strong>DOB:</strong> ${p.DOB || p.dob || "N/A"}<br>
          <strong>Telephone:</strong> ${p.Telephone || p.telephone || "N/A"}
        </p>

        <h4>Patient History & Notes</h4>
        ${
          patientAppts.length
            ? patientAppts.map(a => `
              <div class="noteBox">
                <p><strong>Date:</strong> ${a.date}</p>
                <p><strong>Doctor Note:</strong> ${a.doctor_note || a.notes || "[Encrypted]"}</p>
                <p><strong>Medicine:</strong> ${
                  medicines.find(m => String(m.id) === String(a.medicine_id))?.Drug ||
                  medicines.find(m => String(m.id) === String(a.medicine_id))?.name || "—"
                }</p>
              </div>
            `).join("")
            : "<p>No history yet.</p>"
        }

        <h4>Add New Note / Prescription</h4>
        <textarea id="noteText" placeholder="Add doctor note"></textarea>
        <label>Medicine:
          <select id="medSelect">
            <option value="">-- Select Medicine --</option>
            ${medicines.map(m => `<option value="${m.id}">${m.Drug || m.name}</option>`).join("")}
          </select>
        </label>
        <button id="saveNoteBtn">Save Note & Prescription</button>
      </div>
    `;

    document.getElementById("saveNoteBtn").addEventListener("click", async () => {
      const note = document.getElementById("noteText").value.trim();
      const medId = document.getElementById("medSelect").value;
      if (!note) return alert("Please enter a note.");

      const encNote = await cryptoHelpers.encryptData(note);

      const newRecord = {
        patient_id: p.id,
        doctor_note_encrypted: encNote,
        doctor_note: note,
        medicine_id: medId,
        date: new Date().toISOString().slice(0, 10),
      };

      appointments.push(newRecord);
      localStorage.setItem("appointments", JSON.stringify(appointments));
      await window.DB.addRecord("appointments", newRecord);
      alert("Note & Prescription saved successfully!");
      renderPatient(p);
    });
  }
})();
