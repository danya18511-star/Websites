(async () => {
  /***************************************************************
   * 1.  Encryption + Login helpers 
   ***************************************************************/
  const cryptoHelpers = (() => {
    let sessionKey = null;

    function bufToHex(b) {
      return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
    }
    function hexToBuf(h) {
      const b = new Uint8Array(h.length / 2);
      for (let i = 0; i < b.length; i++) b[i] = parseInt(h.substr(i * 2, 2), 16);
      return b;
    }

    async function ensureSessionKey() {
      if (sessionKey) return;
      const pass = sessionStorage.getItem("app_passphrase") || prompt("Enter encryption passphrase:");
      if (!pass) throw new Error("Encryption passphrase required.");
      sessionStorage.setItem("app_passphrase", pass);
      const enc = new TextEncoder();
      const salt = new Uint8Array([0x42, 0x55, 0x99, 0x12, 0x22, 0x77, 0xA1, 0xFF, 0x10, 0x03, 0xA3, 0xB1, 0x19, 0x90, 0xD2, 0x55]);
      const baseKey = await crypto.subtle.importKey("raw", enc.encode(pass), { name: "PBKDF2" }, false, ["deriveBits", "deriveKey"]);
      sessionKey = await crypto.subtle.deriveKey(
        { name: "PBKDF2", salt, iterations: 200000, hash: "SHA-256" },
        baseKey,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
      );
    }

    async function encryptData(text) {
      await ensureSessionKey();
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const encoded = new TextEncoder().encode(text);
      const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, sessionKey, encoded);
      return { ivHex: bufToHex(iv), cipherHex: bufToHex(cipher) };
    }

    async function decryptData(encObj) {
      await ensureSessionKey();
      const iv = hexToBuf(encObj.ivHex);
      const cipherBuf = hexToBuf(encObj.cipherHex).buffer;
      const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, sessionKey, cipherBuf);
      return new TextDecoder().decode(plainBuf);
    }

    return { encryptData, decryptData };
  })();

  /***************************************************************
   * 2. 👤 Admin Login
   ***************************************************************/
  const adminCredentials = {
    username: "admin",
    passwordHash: "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3" // SHA1("test")
  };

  function sha1(str) {
    return crypto.subtle.digest("SHA-1", new TextEncoder().encode(str))
      .then(buf => Array.from(new Uint8Array(buf)).map(x => x.toString(16).padStart(2, "0")).join(""));
  }

  async function loginAdmin() {
    const storedSession = sessionStorage.getItem("adminLoggedIn");
    if (storedSession === "true") return true;

    let username = prompt("Enter admin username:");
    let password = prompt("Enter admin password:");

    if (!username || !password) {
      alert("Login cancelled");
      return false;
    }

    const hash = await sha1(password);
    if (username === adminCredentials.username && hash === adminCredentials.passwordHash) {
      alert("Login successful!");
      sessionStorage.setItem("adminLoggedIn", "true");
      return true;
    } else {
      alert("Invalid credentials");
      return false;
    }
  }

  const loggedIn = await loginAdmin();
  if (!loggedIn) return;

  /***************************************************************
   * 3. Open DB + DOM references
   ***************************************************************/
  await window.DB.openDatabase();

  const addForm = document.getElementById('addPatientForm');
  const patientsList = document.getElementById('patientsList');
  const search = document.getElementById('searchPatient');

  // --- Load JSON patient data ---
  let jsonPatients = [];
  try {
    const res = await fetch('patient.json');
    jsonPatients = await res.json();
    console.log('JSON patients loaded:', jsonPatients.length);
  } catch (err) {
    console.warn('Failed to load patient.json:', err);
  }

  /***************************************************************
   * 4. Add Patient
   ***************************************************************/
  addForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = new FormData(addForm);
    const patient = Object.fromEntries(f.entries());

    // Encrypt sensitive fields
    try {
      patient.address_encrypted = await cryptoHelpers.encryptData(patient.address || "");
      patient.telephone_encrypted = await cryptoHelpers.encryptData(patient.telephone || "");
      patient.nhs_encrypted = await cryptoHelpers.encryptData(patient.nhs_number || "");
    } catch (err) {
      console.warn("Encryption failed:", err);
    }

    try {
      await window.DB.addRecord('patients', patient);
      renderPatients();
      addForm.reset();
      alert('Patient added');
    } catch (err) {
      alert('Failed to add. ID may already exist.');
    }
  });

  /***************************************************************
   * 5. Render Patients (JSON + DB)
   ***************************************************************/
  async function renderPatients() {
  const q = (search.value || '').toLowerCase().trim();

  const dbPatients = await window.DB.getAll('patients');

  const combined = [
    ...jsonPatients.map(p => ({
      id: p.id,
      name: `${p.Title || ''} ${p.First || ''} ${p.Last || ''}`.trim(),
      address: p.Address,
      telephone: p.Telephone,
      dob: p.DOB,
      nhs_number: p.NHS,
      gender: p.Gender,
      email: p.Email
    })),
    ...dbPatients
  ];

  const nonEmpty = combined.filter(p =>
    (p.name && p.name.trim()) ||
    (p.address && p.address.trim()) ||
    (p.telephone && p.telephone.trim()) ||
    (p.nhs_number && p.nhs_number.toString().trim()) ||
    (p.dob && p.dob.toString().trim())
  );

  let filtered;
  if (/^\d+$/.test(q)) {
    // If the query is only digits, filter strictly by ID
    filtered = nonEmpty.filter(p => (p.id || '').toString() === q);
  } else {
    // Otherwise, filter by name or NHS number
    filtered = nonEmpty.filter(
      p =>
        (p.name || '').toLowerCase().includes(q) ||
        (p.nhs_number || '').toString().includes(q)
    );
  }

  patientsList.innerHTML = filtered
    .map(
      p => `
    <div class="row">
      <div class="info">
        <strong>${p.name || '(No name)'}</strong><br>
        ID: ${p.id || 'N/A'}<br>
        Gender: ${p.gender || '-'}<br>
        DOB: ${p.dob || '-'}<br>
        NHS No: ${p.nhs_number || '-'}<br>
        Address: ${p.address || '-'}<br>
        Telephone: ${p.telephone || '-'}<br>
        Email: ${p.email || '-'}
      </div>
      <div class="actions">
        <button class="editBtn" data-id="${p.id}">Edit</button>
        <button class="delBtn" data-id="${p.id}">Delete</button>
      </div>
    </div>
  `).join('');

  document.querySelectorAll('.delBtn').forEach(btn =>
    btn.addEventListener('click', async (e) => {
      const id = e.target.dataset.id;
      if (confirm('Delete this patient?')) {
        await window.DB.deleteRecord('patients', id);
        renderPatients();
      }
    })
  );

  document.querySelectorAll('.editBtn').forEach(btn =>
    btn.addEventListener('click', async (e) => {
      const id = e.target.dataset.id;
      const patient = await window.DB.getByKey('patients', id);
      if (!patient) return alert('Patient not found in database.');
      openEditForm(patient);
    })
  );
}


  /***************************************************************
   * 6. Edit Form
   ***************************************************************/
  function openEditForm(patient) {
    const formHTML = `
      <div class="modal">
        <div class="modal-content">
          <h3>Edit Patient</h3>
          <form id="editPatientForm">
            <label>ID <input name="id" value="${patient.id}" readonly></label>
            <label>Name <input name="name" value="${patient.name || ''}" required></label>
            <label>Address <input name="address" value="${patient.address || ''}"></label>
            <label>Telephone <input name="telephone" value="${patient.telephone || ''}"></label>
            <label>DOB <input name="dob" type="date" value="${patient.dob || ''}"></label>
            <label>NHS Number <input name="nhs_number" value="${patient.nhs_number || ''}"></label>
            <div class="buttons">
              <button type="submit">Save</button>
              <button type="button" id="cancelEdit">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    `;

    const modal = document.createElement('div');
    modal.innerHTML = formHTML;
    document.body.appendChild(modal);

    const editForm = modal.querySelector('#editPatientForm');
    const cancelBtn = modal.querySelector('#cancelEdit');

    cancelBtn.addEventListener('click', () => modal.remove());

    editForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(editForm);
      const updated = Object.fromEntries(formData.entries());
      await window.DB.updateRecord('patients', updated);
      modal.remove();
      renderPatients();
      alert('Patient updated successfully!');
    });
  }

  /***************************************************************
   * 7. Search listener + initial render
   ***************************************************************/
  search.addEventListener('input', renderPatients);
  renderPatients();

})();
