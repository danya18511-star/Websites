// db.js — IndexedDB setup + JSON load
const DB_NAME = 'HealthcareDB';
const DB_VERSION = 2; // 🔼 bump version so new structure updates properly
let db = null;

async function openDatabase() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      db = e.target.result;

      // --- Create all stores if missing ---
      if (!db.objectStoreNames.contains('patients'))
        db.createObjectStore('patients', { keyPath: 'id' });

      if (!db.objectStoreNames.contains('doctors'))
        db.createObjectStore('doctors', { keyPath: 'id' });

      if (!db.objectStoreNames.contains('admins'))
        db.createObjectStore('admins', { keyPath: 'id' });

      if (!db.objectStoreNames.contains('medicines'))
        db.createObjectStore('medicines', { keyPath: 'id' });

      // ✅ appointments store (autoIncrement true, since we’ll let DB assign id)
      if (!db.objectStoreNames.contains('appointments'))
        db.createObjectStore('appointments', { keyPath: 'id', autoIncrement: true });

      console.log('🗄️ Database structure ensured.');
    };

    req.onsuccess = (e) => {
      db = e.target.result;
      console.log('✅ DB opened successfully:', DB_NAME);
      loadInitialDataIfEmpty();
      resolve(db);
    };

    req.onerror = (e) => {
      console.error('❌ Failed to open DB:', e.target.error);
      reject(e.target.error);
    };
  });
}

async function loadInitialDataIfEmpty() {
  const sources = {
    doctors: 'https://jsethi-mdx.github.io/cst2572.github.io/doctors.json',
    patients: 'https://jsethi-mdx.github.io/cst2572.github.io/patients.json',
    admins: 'https://jsethi-mdx.github.io/cst2572.github.io/admin.json',
    medicines: 'https://jsethi-mdx.github.io/cst2572.github.io/medicines.json',
  };

  for (const [store, url] of Object.entries(sources)) {
    const count = await countStore(store);
    if (count === 0) {
      try {
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();

        const tx = db.transaction(store, 'readwrite');
        const os = tx.objectStore(store);
        data.forEach((item) => os.put(item));

        console.log(`✅ Loaded ${data.length} ${store} records`);
      } catch (err) {
        console.warn(`⚠️ Could not load ${store} from ${url}:`, err);
      }
    }
  }

  // No external JSON for appointments — just ensure the store exists
  const apptCount = await countStore('appointments');
  if (apptCount === 0) {
    console.log('🗓️ Appointments store initialized (empty).');
  }
}

// --- Count helper ---
function countStore(storeName) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.count();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// --- Generic helpers ---
function getAll(storeName) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function getByKey(storeName, key) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.get(Number(key)); // ✅ ensure numeric IDs match keyPath type
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function addRecord(storeName, record) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);

    // 🔧 If store uses autoIncrement, remove manual id
    if (storeName === 'appointments' && record.id) delete record.id;

    const req = store.add(record);
    req.onsuccess = () => {
      console.log(`✅ Added record to ${storeName}`, record);
      resolve(req.result);
    };
    req.onerror = () => reject(req.error);
  });
}

function putRecord(storeName, record) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.put(record);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function deleteRecord(storeName, key) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Export for use in other scripts ---
window.DB = {
  openDatabase,
  getAll,
  getByKey,
  addRecord,
  putRecord,
  deleteRecord,
};
