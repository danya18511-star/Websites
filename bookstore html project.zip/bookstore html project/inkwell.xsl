<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" 
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:bk="http://www.inkwellbookshop.com/books">
<xsl:template match="/">
<html>
<head>
<title>Inkwell Book Collection</title>
<style type="text/css">
:root {
    --color-inkwell: #1A1F2C;
    --color-light: #F6F6F7;
    --color-accent: #8B5CF6;
    --color-vibrant: #F97316;
    --font-sans: 'Inter', sans-serif;
    --font-serif: 'Playfair Display', serif;
}

/* Body */
body {
    font-family: var(--font-sans);
    background-color: var(--color-light);
    color: var(--color-inkwell);
    line-height: 1.6;
    margin: 0;
    padding-top: 80px;
    text-align: center;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

/* Header */
header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.07);
    padding: 15px 0;
    z-index: 100;
}

/* Header Container */
.header .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Logo */
.logo {
    font-family: var(--font-serif);
    font-size: 2rem;
    font-weight: 700;
    color: var(--color-inkwell);
    text-decoration: none;
    position: relative;
}

.logo::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, var(--color-accent), var(--color-vibrant));
    transform: scaleX(0.7);
    transform-origin: left;
    transition: transform 0.4s ease;
}

.logo:hover::after {
    transform: scaleX(1);
}

/* Navigation Menu */
.nav ul {
    display: flex;
    list-style: none;
    gap: 30px;
    padding: 0;
    margin: 0;
}

.nav a {
    font-weight: 500;
    color: var(--color-inkwell);
    text-decoration: none;
    font-size: 1rem;
    padding: 5px 0;
    position: relative;
    transition: color 0.3s ease;
}

.nav a::after {
    content: '';
    position: absolute;
    width: 0;
    height: 2px;
    bottom: 0;
    left: 0;
    background: linear-gradient(90deg, var(--color-accent), var(--color-vibrant));
    transition: width 0.4s ease;
}

.nav a:hover::after {
    width: 100%;
}

/* Heading */
h1 {
    font-family: var(--font-serif);
    font-size: 3.8rem;
    font-weight: 700;
    text-align: center;
    color: var(--color-inkwell);
    position: relative;
    display: inline-block;
    background: linear-gradient(90deg, var(--color-inkwell), var(--color-accent));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    padding: 50px 0;
}

/* Genre Header */
.genre {
    font-size: 2rem; 
    font-weight: bold;
    text-align: center;
    color: #212121;
    position: relative;
    margin-bottom: 20px;
}

.genre::after {
    content: '';
    display: block;
    width: 100px;
    height: 3px;
    background: linear-gradient(90deg, var(--color-accent), var(--color-vibrant));
    margin: 8px auto 0;
}


/* Table */
table {
    width: 90%;
    max-width: 1000px;
    margin: 20px auto;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    overflow: hidden;
}

th, td {
    padding: 16px;
    text-align: left;
}

th {
    background: linear-gradient(90deg, var(--color-inkwell), #35405d);
    font-weight: bold;
    color: white;
}

/* Contact Section */
.contact-section {
    background-color: #f0f0f0;
    text-align: center;
    padding: 50px 20px;
}

.contact-info {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 30px;
      max-width: 1000px;
      margin: 0 auto;
    }
    
    .contact-item {
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 25px 30px;
      background: white;
      border-radius: 15px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
      transition: all 0.3s ease;
    }
    
    .contact-item:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }
    
    .icon {
      font-size: 2.2rem;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 60px;
      height: 60px;
      background: rgba(139, 92, 246, 0.1);
      border-radius: 50%;
      transition: all 0.4s ease;
    }
    
    .contact-item:hover .icon {
      transform: rotate(360deg) scale(1.1);
      background: linear-gradient(135deg, var(--color-accent), var(--color-vibrant));
      color: white;
    }

/* Footer */
footer {
    background: linear-gradient(135deg, #1A1F2C, #2E3A5A);
    color: white;
    text-align: center;
    padding: 20px;
    margin-top: auto;
}
</style>
</head>

<body>

<!-- Header Section -->
<header class="header">
    <div class="container">
        <a href="#" class="logo">Inkwell.</a>
        <nav class="nav">
            <ul>
                <li><a href="inkwell.html">Home</a></li>
                <li><a href="inkwell.xml">Books</a></li>
            </ul>
        </nav>
    </div>
</header>

<!-- Main Content -->
<main>
    <h1>Inkwell Book Collection</h1>
    <xsl:apply-templates select="bk:Books/bk:Genre"/>
</main>

<!-- Contact Section -->
<section class="contact-section">
    <div class="container">
        <h2>Visit Us</h2>
        <div class="contact-info">
            <div class="contact-item">
                <span class="icon">📍</span>
                <p>123 Readers Lane, Bookville, BK 12345</p>
            </div>
            <div class="contact-item">
                <span class="icon">📞</span>
                <p>(555) 123-4567</p>
            </div>
            <div class="contact-item">
                <span class="icon">✉️</span>
                <p>hello@inkwellbooks.com</p>
            </div>
        </div>
    </div>
</section>

<!-- Footer Section -->
<footer>
    <p>© 2025 Inkwell Bookshop. All rights reserved.</p>
</footer>

</body>
</html>
</xsl:template>

<xsl:template match="bk:Genre">
  <div class="genre">
    <xsl:value-of select="@name"/>
  </div>
  <table>
    <tr>
      <th>Title</th>
      <th>Author</th>
      <th>ISBN</th>
      <th>Publication Year</th>
      <th>Price</th>
      <th>InStock</th>
    </tr>
    <xsl:apply-templates select="bk:Book"/>
  </table>
</xsl:template>

<xsl:template match="bk:Book">
  <tr>
    <td><xsl:value-of select="bk:Title"/></td>
    <td><xsl:value-of select="bk:Author"/></td>
    <td><xsl:value-of select="bk:ISBN"/></td>
    <td><xsl:value-of select="bk:PublicationYear"/></td>
    <td><xsl:value-of select="bk:Price"/> <xsl:value-of select="bk:Price/@currency"/></td>
    <td><xsl:value-of select="bk:InStock/@status"/></td>
  </tr>
</xsl:template>
</xsl:stylesheet>

